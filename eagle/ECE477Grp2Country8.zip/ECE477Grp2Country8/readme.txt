PCB Dimenisons: 1.9875" x 1.75"
PCB Area: 3.48 square inches
Copies: 15
